#include "THCSTensor.h"

#include "generic/THCSTensor.c"
#include "THCSGenerateAllTypes.h"
