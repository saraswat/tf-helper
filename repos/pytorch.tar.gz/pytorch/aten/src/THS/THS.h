#ifndef THS_INC
#define THS_INC

#include "THGeneral.h"
#include "THSTensor.h"

#endif
