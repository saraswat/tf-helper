#include "THSTensor.h"

#include "generic/THSTensor.c"
#include "THSGenerateAllTypes.h"

#include "generic/THSTensorMath.c"
#include "THSGenerateAllTypes.h"
