#!/bin/bash
cp build/src/ATen/ATen/{Tensor,Type,Functions}.h doc

