torch.utils.model_zoo
===================================

.. automodule:: torch.utils.model_zoo
.. autofunction:: load_url
