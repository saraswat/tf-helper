Legacy package - torch.legacy
===================================

.. automodule:: torch.legacy
